package com.anvilcel.app

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Engine {
    private lateinit var ctx: Context
    private val procs = HashMap<String, Proc>()
    private val lock = Any()

    class Proc(val p: Process) { val lines = ArrayList<String>(); var off = 0 }

    fun init(c: Context) { ctx = c.applicationContext; root().mkdirs() }

    private fun root() = File(ctx.filesDir, "servers")
    private fun sdir(i: String) = File(root(), i)
    private fun metaF(i: String) = File(sdir(i), "anvil.json")
    private fun load(i: String) = JSONObject(metaF(i).readText())
    private fun running(i: String) = procs[i]?.p?.isAlive == true
    private fun msg(s: String) = JSONObject().put("msg", s).toString()

    fun call(full: String, bodyStr: String): String {
        val path = full.substringBefore("?")
        val q = full.substringAfter("?", "")
        val d = try { JSONObject(bodyStr) } catch (e: Exception) { JSONObject() }
        val id = path.substringAfterLast("/")
        return try {
            when {
                path == "/api/servers" -> servers().toString()
                path == "/api/net" -> net().toString()
                path.startsWith("/api/log/") -> log(id, q.substringAfter("from=", "0").toIntOrNull() ?: 0).toString()
                path == "/api/create" -> JSONObject().put("id", create(d)).toString()
                path.startsWith("/api/start/") -> msg(start(id))
                path.startsWith("/api/stop/") -> msg(stop(id))
                path.startsWith("/api/backup/") -> msg(backup(id))
                path.startsWith("/api/delete/") -> { stop(id); Thread.sleep(1500); sdir(id).deleteRecursively(); msg("ok") }
                path.startsWith("/api/cmd/") -> {
                    procs[id]?.takeIf { it.p.isAlive }?.p?.outputStream?.let { it.write((d.optString("cmd") + "\n").toByteArray()); it.flush() }
                    msg("ok")
                }
                path.startsWith("/api/update/") -> {
                    val m = load(id)
                    for (k in listOf("name", "port", "maxPlayers", "gamemode", "difficulty", "offline", "whitelist")) if (d.has(k)) m.put(k, d.get(k))
                    metaF(id).writeText(m.toString()); msg("ok")
                }
                else -> msg("rota desconhecida")
            }
        } catch (e: Exception) { msg("erro: " + e.message) }
    }

    private fun servers(): JSONArray {
        val a = JSONArray()
        root().listFiles()?.sortedBy { it.name }?.forEach { f ->
            if (File(f, "anvil.json").exists()) a.put(load(f.name).put("id", f.name).put("running", running(f.name)))
        }
        return a
    }

    private fun create(d: JSONObject): String {
        val i = UUID.randomUUID().toString().substring(0, 8)
        File(sdir(i), "plugins").mkdirs()
        val m = JSONObject()
            .put("name", d.optString("name").ifBlank { "Survival World" })
            .put("software", "pocketmine")
            .put("port", d.optString("port").toIntOrNull() ?: 19132)
            .put("maxPlayers", d.optString("maxPlayers").toIntOrNull() ?: 10)
            .put("gamemode", d.optString("gamemode", "survival"))
            .put("difficulty", d.optString("difficulty", "normal"))
            .put("offline", d.optBoolean("offline", true))
            .put("whitelist", d.optBoolean("whitelist", false))
        metaF(i).writeText(m.toString()); writeProps(i, m)
        return i
    }

    private fun writeProps(i: String, m: JSONObject) {
        val gm = when (m.optString("gamemode")) { "creative" -> 1; "adventure" -> 2; else -> 0 }
        val df = when (m.optString("difficulty")) { "peaceful" -> 0; "easy" -> 1; "hard" -> 3; else -> 2 }
        val new = mapOf(
            "motd" to m.optString("name"), "server-name" to m.optString("name"),
            "server-port" to m.optInt("port", 19132).toString(),
            "max-players" to m.optInt("maxPlayers", 10).toString(),
            "gamemode" to gm.toString(), "difficulty" to df.toString(),
            "xbox-auth" to (if (m.optBoolean("offline", true)) "off" else "on"),
            "white-list" to (if (m.optBoolean("whitelist")) "on" else "off")
        )
        val f = File(sdir(i), "server.properties")
        val cur = LinkedHashMap<String, String>()
        if (f.exists()) f.readLines().forEach { if (it.contains("=") && !it.startsWith("#")) cur[it.substringBefore("=")] = it.substringAfter("=") }
        cur.putAll(new)
        f.writeText(cur.entries.joinToString("\n") { "${it.key}=${it.value}" } + "\n")
    }

    private fun prepareRuntime(): File {
        val rt = File(ctx.filesDir, "runtime"); rt.mkdirs()
        val phar = File(rt, "PocketMine-MP.phar")
        if (!phar.exists()) ctx.assets.open("PocketMine-MP.phar").use { inp -> phar.outputStream().use { inp.copyTo(it) } }
        File(rt, "php.ini").writeText("memory_limit=1024M\ndisplay_errors=1\nerror_reporting=-1\nzend.assertions=-1\ndate.timezone=UTC\n")
        File(rt, "resolv.conf").writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
        return rt
    }

    private fun start(i: String): String {
        if (running(i)) return "ja esta rodando"
        val php = File(ctx.applicationInfo.nativeLibraryDir, "libphp.so")
        if (!php.exists()) return "PHP nao veio no APK (build sem o binario)"
        val m = load(i); writeProps(i, m)
        val rt = try { prepareRuntime() } catch (e: Exception) { return "PocketMine nao veio no APK: " + e.message }
        val dir = sdir(i)
        val pb = ProcessBuilder(php.path, "-c", File(rt, "php.ini").path, File(rt, "PocketMine-MP.phar").path,
            "--no-wizard", "--disable-ansi", "--data=" + dir.path, "--plugins=" + File(dir, "plugins").path)
        pb.directory(dir); pb.redirectErrorStream(true)
        pb.environment()["LESMI_RESOLV_CONF_DIR"] = File(rt, "resolv.conf").path
        pb.environment()["TMPDIR"] = ctx.cacheDir.path
        pb.environment()["HOME"] = dir.path
        val p = try { pb.start() } catch (e: Exception) { return "falha ao executar PHP: " + e.message }
        val pr = Proc(p); pr.lines.add("[AnvilCel] Iniciando..."); procs[i] = pr
        ctx.startForegroundService(Intent(ctx, ServerService::class.java))
        Thread {
            val log = File(dir, "console.log")
            p.inputStream.bufferedReader().forEachLine { l0 ->
                val l = l0.replace(Regex("\u001B\\[[0-9;]*[A-Za-z]"), "")
                synchronized(lock) {
                    pr.lines.add(l)
                    if (pr.lines.size > 3000) { repeat(1000) { pr.lines.removeAt(0) }; pr.off += 1000 }
                }
                try { log.appendText(l + "\n") } catch (e: Exception) { }
            }
            synchronized(lock) { pr.lines.add("[AnvilCel] Servidor parado.") }
            if (procs.values.none { it.p.isAlive }) ctx.stopService(Intent(ctx, ServerService::class.java))
        }.start()
        return "ok"
    }

    private fun stop(i: String): String {
        val p = procs[i]?.p ?: return "ok"
        if (!p.isAlive) return "ok"
        try { p.outputStream.write("stop\n".toByteArray()); p.outputStream.flush() } catch (e: Exception) { }
        Thread { try { Thread.sleep(25000) } catch (e: Exception) { }; if (p.isAlive) p.destroy() }.start()
        return "ok"
    }

    private fun log(i: String, from: Int): JSONObject {
        val r = procs[i] ?: return JSONObject().put("lines", JSONArray()).put("next", 0).put("running", false)
        synchronized(lock) {
            val start = maxOf(0, from - r.off)
            val a = JSONArray(); for (k in start until r.lines.size) a.put(r.lines[k])
            return JSONObject().put("lines", a).put("next", r.off + r.lines.size).put("running", r.p.isAlive)
        }
    }

    private fun net(): JSONObject {
        var local: String? = null
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (ni.isLoopback || !ni.isUp) continue
                for (a in ni.inetAddresses) if (a is Inet4Address && !a.isLoopbackAddress) { local = a.hostAddress; break }
                if (local != null) break
            }
        } catch (e: Exception) { }
        var pub: String? = null
        try {
            val c = URL("https://api.ipify.org").openConnection(); c.connectTimeout = 5000; c.readTimeout = 5000
            pub = c.getInputStream().bufferedReader().readText()
        } catch (e: Exception) { }
        return JSONObject().put("local", local ?: JSONObject.NULL).put("public", pub ?: JSONObject.NULL)
    }

    private fun backup(i: String): String {
        val out = File(ctx.getExternalFilesDir(null), "backups"); out.mkdirs()
        val z = File(out, "$i-${System.currentTimeMillis() / 1000}.zip")
        val base = sdir(i)
        ZipOutputStream(z.outputStream()).use { zo ->
            base.walkTopDown().filter { it.isFile }.forEach { f ->
                zo.putNextEntry(ZipEntry(f.relativeTo(base).path)); f.inputStream().use { it.copyTo(zo) }; zo.closeEntry()
            }
        }
        return "salvo em Android/data/com.anvilcel.app/files/backups/" + z.name
    }
}
